"""AI provider module placeholder for the next MedMCQ modular refactor.

The live provider routing is still in bot.py for deployment compatibility.
"""
