"""Past-papers module placeholder for the next MedMCQ modular refactor."""
