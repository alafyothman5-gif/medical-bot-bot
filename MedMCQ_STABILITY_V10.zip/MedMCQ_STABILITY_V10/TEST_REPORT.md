# TEST REPORT — V10 Stability Smoke Test

Date: 2026-06-19
Build: `MedMCQ_STABILITY_V10`
Scope: offline stability tests using fake Telegram `Update` / `Context` objects. No real Telegram bot token, no real AI key, and no server process were used.

## Result

✅ Offline stability smoke tests passed.

Command used:

```bash
python3 -m py_compile bot.py worker.py queue_jobs.py *.py scripts/*.py
python3 scripts/check_project.py
python3 scripts/stability_smoke_test.py
```

## Verified locally

| Area | Result |
|---|---:|
| Python syntax compile | ✅ Passed |
| Project structural check | ✅ Passed |
| No real `.env` in package | ✅ Passed |
| Obsolete payment tables dropped by `init_db()` | ✅ Passed |
| Payment/OSCE command-menu entries absent | ✅ Passed |
| Student command list compact | ✅ Passed |
| Admin command scope compact: `/admin` only | ✅ Passed |
| Callback router containment | ✅ Passed |
| Static and representative dynamic callbacks | ✅ Passed |
| PDF/DOCX/PPTX/TXT extraction | ✅ Passed |
| Corrupted PDF handling returns empty text instead of crashing | ✅ Passed |
| Quiz upload flow creates pending file and starts Basic quiz | ✅ Passed |
| Summary generation and cache path | ✅ Passed |
| Queue fallback decision does not block direct generation in offline mode | ✅ Passed |
| Admin question edit preserves fingerprint | ✅ Passed |
| Admin question delete removes only matching attempt/wrong rows | ✅ Passed |
| Slide Deck ZIP upload | ✅ Passed |
| Slide image/question display path | ✅ Passed |
| Slide keyword grading | ✅ Passed |

## Important limitation

These tests are not a replacement for live Telegram testing. The following still need confirmation on the actual server:

1. Real Telegram buttons render and edit correctly in the client.
2. Real AI provider keys work.
3. Real Redis/worker production behavior if queue mode is enabled.
4. Existing production SQLite data remains consistent after first V10 startup.
5. Admin log channel receives `/start` alerts as expected.

## Live server test checklist

Run after deployment:

```bash
pgrep -af "python.*/root/medical_bot/bot.py"
tail -n 120 /root/medical_bot/bot.log
```

Then test in Telegram:

1. `/start`
2. Student buttons: Past Papers, Slides, Quiz from Lecture, Summary, Progress, Support.
3. Upload TXT/PDF/DOCX/PPTX as student.
4. Basic/Cases/Challenge generation.
5. Summary generation and cached repeat upload.
6. `/admin`
7. Admin question manager: browse, edit answer, delete test question, add JSON question.
8. Slide Deck upload as admin and training as student.
9. Admin staging and lecture preload.
10. Confirm `/osce` and payment commands are absent from Telegram command list.
