"""Configuration boundary for the next MedMCQ modular refactor.

Runtime remains compatible with bot.py in this build. Keep secrets in .env only.
"""

from __future__ import annotations

import os
import re
from typing import List


def env_bool(name: str, default: str = "0") -> bool:
    return os.environ.get(name, default).strip().lower() in {"1", "true", "yes", "on"}


def env_keys(*names: str) -> List[str]:
    raw_parts = [os.environ.get(name, "") for name in names if os.environ.get(name, "")]
    return [item.strip() for item in re.split(r"[,;\s]+", "\n".join(raw_parts)) if item.strip()]
