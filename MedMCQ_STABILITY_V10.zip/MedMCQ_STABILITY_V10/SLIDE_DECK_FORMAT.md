# Slide Training Deck Format

Deck السلايدات يكون ZIP يحتوي:

```text
deck.json
images/slide_001.jpg
images/slide_002.jpg
```

## صيغة `deck.json`

```json
{
  "deck_id": "ajdabiya_slide_training_v1",
  "title": "Ajdabiya Clinical Slides",
  "admin_only": false,
  "slides": [
    {
      "slide_id": "SLIDE-001",
      "slide_number": 1,
      "image": "images/slide_001.jpg",
      "questions": [
        {
          "id": "S001-Q1",
          "question": "What is the diagnosis?",
          "answer": "Erb's palsy",
          "accepted_keywords": [
            "erb",
            "erb palsy",
            "brachial plexus injury",
            "شلل ارب"
          ],
          "explanation": "Optional explanation."
        }
      ]
    }
  ]
}
```

## الحقول المهمة

| الحقل | مطلوب | الوصف |
|---|---:|---|
| `deck_id` | نعم | معرف ثابت للـ Deck |
| `title` | نعم | عنوان يظهر للطالب |
| `slides` | نعم | قائمة السلايدات |
| `slide_id` | مفضل | معرف السلايد |
| `slide_number` | مفضل | رقم السلايد |
| `image` | نعم | مسار صورة السلايد |
| `questions` | نعم | أسئلة السلايد |
| `id` | مفضل | معرف السؤال |
| `question` | نعم | نص السؤال |
| `answer` | نعم | الإجابة النموذجية |
| `accepted_keywords` | نعم | كلمات يقبلها التصحيح |
| `explanation` | اختياري | شرح يظهر بعد الإجابة |

## أكثر من صورة للسؤال

يمكن استخدام `images` بدل `image`:

```json
{
  "slide_id": "S-001",
  "images": ["images/a.jpg", "images/b.jpg"],
  "questions": []
}
```

أو داخل السؤال نفسه:

```json
{
  "id": "Q1",
  "question": "Identify the finding.",
  "images": ["images/finding_1.jpg", "images/finding_2.jpg"],
  "answer": "...",
  "accepted_keywords": ["..."]
}
```

## حدود الأمان الحالية

يمكن تعديلها من `.env`:

```env
SLIDE_DECK_MAX_ZIP_MB=100
SLIDE_DECK_MAX_FILES=300
SLIDE_DECK_MAX_UNCOMPRESSED_MB=250
```

الأنواع المسموحة داخل ZIP:

```text
.json, .jpg, .jpeg, .png, .webp
```
