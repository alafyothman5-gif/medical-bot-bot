# Cleanup Report — MedMCQ V10

## Removed earlier

- Payment/subscription UI and command flows.
- Payment admin flows.
- OSCE simulator command, callbacks, menu entries, translation keys, and file branch.

## Kept intentionally

- AI-provider keys and AI fallback configuration remain available because they are unrelated to Telegram payments/subscriptions.
- Compatibility stubs for plan getters remain so old dashboard/progress code does not crash.
- `DROP TABLE IF EXISTS` for obsolete payment tables remains in `init_db()` so old production databases are cleaned on startup.

## Added in V10

- Offline smoke test script: `scripts/stability_smoke_test.py`.
- Extra SQLite indexes for progress, usage, past-paper, and cache performance.
- SQLite `ANALYZE` during startup.
- Optional `VACUUM` via `DB_RUN_VACUUM_ON_INIT=1`.
- Large `wrong_json` cleanup using `WRONG_JSON_MAX_BYTES`.
- Cleaner warning-level extraction error handling for corrupted files.

## Not done yet

Full modularization is still pending. Placeholder modules exist, but the operational entrypoint remains `bot.py` to avoid breaking the running deployment path before live Telegram regression testing.
