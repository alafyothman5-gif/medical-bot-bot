# CHANGELOG — MedMCQ Clean Build

## V10 — Stability and Performance Pass

### Stability tests

- Added `scripts/stability_smoke_test.py` for offline regression testing without Telegram or AI keys.
- Tested fake Telegram callback routing for static and representative dynamic callbacks.
- Tested student file upload flow for quiz setup and summary generation with mocked AI.
- Tested cache reuse for summaries.
- Tested corrupted PDF extraction path to ensure it returns a safe empty result rather than crashing.
- Tested Admin Question Manager update/delete logic.
- Tested Slide Training Deck upload, image path loading, session start, and keyword grading.

### Database performance

- Added SQLite indexes for common lookup paths:
  - `past_question_attempts(fp)`
  - `past_question_attempts(uni, subject, fp)`
  - `past_progress(user_id)`
  - `past_progress(uni, subject)`
  - `user_daily_usage(user_id, day)`
  - `user_daily_usage(day, kind)`
  - `past_papers(uni, subject)`
  - `files(created_at)`
  - `xp_events(user_id, created_at)`
- Added `ANALYZE` during `init_db()` for SQLite planner statistics.
- Added optional `VACUUM` during startup only when `DB_RUN_VACUUM_ON_INIT=1`.
- Added automatic cleanup for `past_progress.wrong_json` rows larger than `WRONG_JSON_MAX_BYTES` default `1048576`.

### File handling

- Changed extraction error logging from stack-trace noise to warning-level message for expected corrupted uploads.
- Corrupted or unsupported extraction still returns an empty string so `handle_file` can show a user-facing error.

### Cleanup

- Updated misleading internal labels from old paid/subscription wording where possible without changing AI-provider compatibility variables.
- Removed stale clinical simulator comment left after the no-OSCE cleanup.

## V9 — No Payments / No OSCE

- Removed Telegram payment/subscription UI routes and command handlers.
- Removed payment admin callback handling.
- Removed payment environment variables from `.env.example`.
- Removed OSCE simulator V4 functions, callbacks, command, file-processing branch, menu button, command menu entry, and translation keys.
- Simplified user plan handling: admins return `admin`; all other users return `free`.
- Added startup `DROP TABLE IF EXISTS` for obsolete payment tables:
  - `payments`
  - `payment_orders`
  - `processed_sms`
  - `unmatched_madar_sms`
  - `unclaimed_madar_sms`
