# Deploy MedMCQ on server

## 1. تجهيز الملفات

من داخل مجلد المشروع:

```bash
./scripts/clean_project.sh
python3 scripts/check_project.py
python3 -m py_compile bot.py worker.py queue_jobs.py main.py
```

## 2. تثبيت الاعتمادات

```bash
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
mkdir -p data
```

## 3. تجهيز `.env`

```bash
cp .env.example .env
nano .env
```

املأ على الأقل:

```env
TELEGRAM_BOT_TOKEN=...
ADMIN_USER_IDS=123456789
DATABASE_PATH=data/bot_cache.sqlite3
```

ثم أضف مفاتيح AI التي تريد استخدامها.

## 4. قناة Admin Log

لإرسال تنبيه عند دخول الطالب للبوت عبر `/start` فقط، اجعل البوت Admin داخل قناة/جروب اللوق، ثم ضع:

```env
ADMIN_LOG_CHAT_ID=-100xxxxxxxxxx
ADMIN_ACTIVITY_LOG_ENABLED=1
ADMIN_START_ALERT_ENABLED=1
ADMIN_START_ALERT_COOLDOWN_SECONDS=3600
```

السلوك:

- يرسل تنبيه عند `/start` فقط.
- لا يسجل الأزرار أو حل الأسئلة أو النصوص العادية.
- نفس المستخدم لا يظهر مرة ثانية إلا بعد ساعة افتراضيًا.

## 5. تشغيل البوت

```bash
python3 -m py_compile bot.py worker.py queue_jobs.py main.py
nohup python3 bot.py > nohup.out 2>&1 &
```

لو `USE_QUEUE=1`:

```bash
nohup python3 worker.py > worker.log 2>&1 &
```

## 6. فحص اللوق

```bash
tail -100 nohup.out
tail -100 worker.log
```

## 7. إعادة تشغيل آمنة على السيرفر الحالي

لا تستخدم `pkill python` ولا تلمس أي خدمة أخرى.

```bash
pkill -f "python.*/root/medical_bot/bot.py" || true
cd /root/medical_bot
nohup /root/medical_bot/.venv/bin/python /root/medical_bot/bot.py >> /root/medical_bot/bot.log 2>&1 &
```

## ملاحظات مهمة

- هذه النسخة لا تحتوي نظام دفع.
- هذه النسخة لا تحتوي محاكي OSCE.
- عند التشغيل، يقوم `init_db()` بحذف جداول الدفع القديمة إن كانت موجودة: `payments`, `payment_orders`, `processed_sms`, `unmatched_madar_sms`, `unclaimed_madar_sms`.
- قاعدة SQLite يجب أن تبقى على السيرفر ولا تُرفع إلى GitHub.
