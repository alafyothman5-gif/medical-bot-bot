"""Database module placeholder for the next MedMCQ modular refactor.

The live database implementation is still in bot.py for deployment compatibility.
"""
