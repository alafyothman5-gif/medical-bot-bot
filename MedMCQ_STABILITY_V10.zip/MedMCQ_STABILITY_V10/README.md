# MedMCQ Bot — Clean No-Payments / No-OSCE Build

نسخة تشغيل نظيفة من بوت MedMCQ، جاهزة للنشر بدون ملفات أسرار أو كاش تشغيل، وبدون نظام دفع أو محاكي OSCE.

## الحالة الحالية

- Entry point الحالي: `bot.py`
- سكربتات مساعدة: `worker.py`, `queue_jobs.py`
- قاعدة البيانات في التشغيل الحقيقي تؤخذ من `.env` عبر `DATABASE_PATH`
- لا يحتوي هذا ZIP على `.env` الحقيقي أو قاعدة تشغيل SQLite

## الميزات المتبقية

| الميزة | الحالة |
|---|---:|
| رفع PDF/DOCX/PPTX/TXT | موجود |
| استخراج النص | موجود |
| توليد Basic/Cases/Challenge | موجود |
| توليد الملخصات | موجود |
| الكاش للملفات والأسئلة والملخصات | موجود |
| Past Papers | موجود |
| Admin Question Manager | موجود |
| Slide Training | موجود |
| Admin staging | موجود |
| Admin log لـ `/start` | موجود |
| الدفع والاشتراكات | محذوف |
| محاكي OSCE | محذوف |

## أوامر الطالب الظاهرة في Telegram

```text
/start
/help
/stats
/review
/slides
/support
/stop
```

## أوامر الأدمن الظاهرة في Telegram scope

```text
/admin
```

باقي أوامر الأدمن تعمل من داخل لوحة الأدمن أو كأوامر مباشرة عند الحاجة، لكنها غير معروضة في قائمة Telegram العامة.

## اختبارات محلية قبل النشر

```bash
python3 -m py_compile bot.py worker.py queue_jobs.py *.py scripts/*.py
python3 scripts/check_project.py
python3 scripts/stability_smoke_test.py
```

## ملاحظات قاعدة البيانات

عند أول تشغيل، يقوم `init_db()` بحذف جداول الدفع القديمة إن كانت موجودة:

```text
payments
payment_orders
processed_sms
unmatched_madar_sms
unclaimed_madar_sms
```

كما يضيف فهارس أداء على جداول الاستخدام، التقدم، السنوات السابقة، والسلايدات.

## متغيرات مفيدة

```env
USE_QUEUE=1
AUTO_QUEUE_FALLBACK=1
QUEUE_REQUIRE_WORKER_PROCESS=1
WRONG_JSON_MAX_BYTES=1048576
DB_RUN_VACUUM_ON_INIT=0
```

- اترك `DB_RUN_VACUUM_ON_INIT=0` افتراضيًا.
- استخدم `DB_RUN_VACUUM_ON_INIT=1` مرة واحدة فقط عند الحاجة لصيانة قاعدة كبيرة، وليس في كل تشغيل.

## التقسيم إلى Modules

توجد ملفات modules تمهيدية مثل `config.py`, `database.py`, `ai_providers.py`, `file_utils.py`, `quiz.py`, `summary.py`, `past_papers.py`, `slide_training.py`, `admin_staging.py`, `handlers.py`, `utils.py`, و `main.py`.

التشغيل الفعلي بقي في `bot.py` مؤقتًا. النقل الكامل من `bot.py` إلى هذه الوحدات يحتاج مرحلة refactor منفصلة بعد تثبيت النسخة على السيرفر واختبارها حيًا.
