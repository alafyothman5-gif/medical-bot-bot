"""Slide-training module placeholder for the next MedMCQ modular refactor."""
