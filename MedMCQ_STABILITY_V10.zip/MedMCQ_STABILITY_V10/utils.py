"""General utilities module placeholder for the next MedMCQ modular refactor."""
