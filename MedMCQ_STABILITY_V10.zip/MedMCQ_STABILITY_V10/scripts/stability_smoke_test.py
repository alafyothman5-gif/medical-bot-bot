#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline stability smoke tests for MedMCQ.

These tests do not contact Telegram or AI providers. They use fake Update/Context
objects and monkeypatch AI generation so the critical local flows can be checked
before deploying a ZIP to the server.
"""

from __future__ import annotations

import asyncio
import io
import json
import os
import pathlib
import re
import sqlite3
import sys
import zipfile
from types import SimpleNamespace

ROOT = pathlib.Path(__file__).resolve().parents[1]
RUNTIME = ROOT / ".smoke_runtime"
RUNTIME.mkdir(exist_ok=True)

os.environ.setdefault("TELEGRAM_BOT_TOKEN", "123:SMOKE")
os.environ["DATABASE_PATH"] = str(RUNTIME / "smoke.sqlite3")
os.environ.setdefault("ADMIN_USER_IDS", "111")
os.environ.setdefault("COOLDOWN_SECONDS", "0")
os.environ.setdefault("USE_QUEUE", "1")
os.environ.setdefault("AUTO_QUEUE_FALLBACK", "1")
os.environ.setdefault("QUEUE_REQUIRE_WORKER_PROCESS", "1")
os.environ["SLIDE_TRAINING_DIR"] = str(RUNTIME / "slide_training")

sys.path.insert(0, str(ROOT))

from docx import Document  # noqa: E402
from pptx import Presentation  # noqa: E402
from pptx.util import Inches  # noqa: E402
from telegram.ext import ApplicationHandlerStop  # noqa: E402

import bot  # noqa: E402

try:
    from PIL import Image  # noqa: E402
except Exception:  # pragma: no cover
    Image = None

try:
    import fitz  # type: ignore  # noqa: E402
except Exception:  # pragma: no cover
    fitz = None


class FakeUser:
    def __init__(self, user_id: int, name: str = "User") -> None:
        self.id = user_id
        self.full_name = name
        self.username = name.lower().replace(" ", "_")


class FakeChat:
    def __init__(self, chat_id: int = 333) -> None:
        self.id = chat_id


class FakeTGFile:
    def __init__(self, raw: bytes) -> None:
        self.raw = raw

    async def download_as_bytearray(self) -> bytearray:
        return bytearray(self.raw)


class FakeDocument:
    def __init__(self, name: str, mime: str, raw: bytes) -> None:
        self.file_name = name
        self.mime_type = mime
        self.file_size = len(raw)
        self._raw = raw

    async def get_file(self) -> FakeTGFile:
        return FakeTGFile(self._raw)


class FakeSent:
    def __init__(self, sink: list, text: str = "") -> None:
        self.sink = sink
        self.text = text

    async def edit_text(self, text: str, **kwargs):
        self.sink.append(("edit", str(text)[:220], bool(kwargs.get("reply_markup"))))
        return self

    async def delete(self):
        self.sink.append(("delete", "", False))
        return None


class FakeMessage:
    def __init__(self, doc: FakeDocument | None = None, chat_id: int = 333) -> None:
        self.document = doc
        self.chat = FakeChat(chat_id)
        self.chat_id = chat_id
        self.outputs: list[tuple[str, str, bool]] = []
        self.text = ""
        self.caption = ""
        self.photo = []

    async def reply_text(self, text: str, **kwargs):
        self.outputs.append(("reply", str(text)[:220], bool(kwargs.get("reply_markup"))))
        return FakeSent(self.outputs, text)

    async def reply_photo(self, *args, **kwargs):
        self.outputs.append(("photo", str(kwargs.get("caption", ""))[:220], bool(kwargs.get("reply_markup"))))
        return FakeSent(self.outputs)

    async def reply_document(self, *args, **kwargs):
        self.outputs.append(("doc", str(kwargs.get("caption", ""))[:220], bool(kwargs.get("reply_markup"))))
        return FakeSent(self.outputs)

    async def delete(self):
        self.outputs.append(("delete", "", False))
        return None


class FakeQuery:
    def __init__(self, data: str, user: FakeUser, msg: FakeMessage) -> None:
        self.data = data
        self.from_user = user
        self.message = msg
        self.edits: list[tuple[str, str, bool]] = []
        self.answered: list[tuple[str | None, bool]] = []

    async def answer(self, text: str | None = None, show_alert: bool = False):
        self.answered.append((text, show_alert))
        return None

    async def edit_message_text(self, text: str, **kwargs):
        self.edits.append(("editq", str(text)[:220], bool(kwargs.get("reply_markup"))))
        return FakeSent(self.edits)

    async def edit_message_reply_markup(self, **kwargs):
        self.edits.append(("markup", "", False))
        return None

    async def edit_message_media(self, *args, **kwargs):
        self.edits.append(("media", "", bool(kwargs.get("reply_markup"))))
        return FakeSent(self.edits)


class FakeBot:
    def __init__(self, sink: list | None = None) -> None:
        self.sink = sink if sink is not None else []

    async def send_message(self, chat_id, text, **kwargs):
        self.sink.append(("send_msg", str(text)[:220], bool(kwargs.get("reply_markup"))))
        return FakeSent(self.sink)

    async def send_photo(self, chat_id, photo, caption=None, reply_markup=None, **kwargs):
        self.sink.append(("send_photo", str(caption or "")[:220], bool(reply_markup)))
        return FakeSent(self.sink)

    async def send_document(self, *args, **kwargs):
        self.sink.append(("send_doc", str(kwargs.get("caption", ""))[:220], False))
        return FakeSent(self.sink)


class FakeContext:
    def __init__(self) -> None:
        self.user_data: dict = {}
        self.chat_data: dict = {}
        self.bot = FakeBot()
        self.args: list[str] = []


def make_update(doc: FakeDocument | None = None, user_id: int = 222, chat_id: int = 333):
    user = FakeUser(user_id, "Admin" if user_id == 111 else "Student")
    msg = FakeMessage(doc, chat_id=chat_id)
    return SimpleNamespace(
        effective_user=user,
        effective_chat=msg.chat,
        message=msg,
        effective_message=msg,
    ), msg


async def route_callback(data: str, ctx: FakeContext, user_id: int = 111):
    user = FakeUser(user_id, "Admin" if user_id == 111 else "Student")
    msg = FakeMessage()
    ctx.bot = FakeBot(msg.outputs)
    query = FakeQuery(data, user, msg)
    update = SimpleNamespace(
        callback_query=query,
        effective_user=user,
        effective_chat=msg.chat,
        message=msg,
        effective_message=msg,
    )
    try:
        await bot.universal_callback_router(update, ctx)
    except ApplicationHandlerStop:
        pass
    return query, msg


def assert_true(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def reset_db() -> None:
    db = pathlib.Path(bot.DATABASE_PATH)
    for path in [db, pathlib.Path(str(db) + "-wal"), pathlib.Path(str(db) + "-shm")]:
        if path.exists():
            path.unlink()
    bot.init_db()


async def fake_call_gemini(prompt: str, temperature: float = 0.2, max_output_tokens: int = 8192, **kwargs) -> str:
    if "Return valid JSON array" in prompt or "Generate" in prompt:
        return json.dumps(
            [
                {
                    "question": "What marker rises in myocardial infarction?",
                    "options": {"A": "Troponin", "B": "Hemoglobin", "C": "Albumin", "D": "Insulin", "E": "Creatinine"},
                    "correct": "A",
                    "explanation": "Troponin rises in MI.",
                },
                {
                    "question": "First-line antiplatelet in MI?",
                    "options": {"A": "Aspirin", "B": "Warfarin", "C": "Insulin", "D": "Metformin", "E": "Amoxicillin"},
                    "correct": "A",
                    "explanation": "Aspirin is used.",
                },
                {
                    "question": "ECG finding in STEMI?",
                    "options": {"A": "ST elevation", "B": "QT shortening", "C": "U waves only", "D": "Flat T always", "E": "No change"},
                    "correct": "A",
                    "explanation": "ST elevation suggests STEMI.",
                },
                {
                    "question": "Chest pain radiation common site?",
                    "options": {"A": "Left arm", "B": "Toe", "C": "Knee", "D": "Ear only", "E": "Scalp"},
                    "correct": "A",
                    "explanation": "Can radiate to left arm.",
                },
                {
                    "question": "Enzyme biomarker?",
                    "options": {"A": "CK-MB", "B": "ALT only", "C": "TSH", "D": "PSA", "E": "CRP only"},
                    "correct": "A",
                    "explanation": "CK-MB can rise.",
                },
            ],
            ensure_ascii=False,
        )
    return "ملخص طبي تجريبي منظم عن احتشاء عضلة القلب والتروبونين والتخطيط."


def test_database_init_and_cleanup() -> None:
    db = pathlib.Path(bot.DATABASE_PATH)
    if db.exists():
        db.unlink()
    con = sqlite3.connect(db)
    for table in ["payments", "payment_orders", "processed_sms", "unmatched_madar_sms", "unclaimed_madar_sms"]:
        con.execute(f"CREATE TABLE {table}(id INTEGER)")
    con.commit()
    con.close()
    bot.init_db()
    con = sqlite3.connect(db)
    rows = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    idxs = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='index'").fetchall()]
    con.close()
    obsolete = {"payments", "payment_orders", "processed_sms", "unmatched_madar_sms", "unclaimed_madar_sms"} & set(rows)
    assert_true(not obsolete, f"obsolete payment tables still present: {obsolete}")
    for idx in ["idx_past_question_attempts_fp", "idx_past_progress_user", "idx_user_daily_usage_user_day"]:
        assert_true(idx in idxs, f"missing index: {idx}")


def test_text_extraction() -> None:
    text = ("Cardiology lecture about myocardial infarction. Troponin ECG aspirin. " * 4).encode()
    assert_true(bot.classify_document("text/plain", "lecture.txt") == "txt", "txt classification failed")
    assert_true(len(bot.extract_text("txt", text)) > 100, "txt extraction failed")

    mem = io.BytesIO()
    doc = Document()
    doc.add_paragraph("Respiratory lecture: pneumonia, cough, fever, antibiotics.")
    doc.save(mem)
    assert_true("pneumonia" in bot.extract_text("docx", mem.getvalue()).lower(), "docx extraction failed")

    mem = io.BytesIO()
    prs = Presentation()
    slide = prs.slides.add_slide(prs.slide_layouts[5])
    box = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(5), Inches(1))
    box.text = "Endocrine slide: diabetes mellitus insulin glucose."
    prs.save(mem)
    assert_true("diabetes" in bot.extract_text("pptx", mem.getvalue()).lower(), "pptx extraction failed")

    if fitz is not None:
        pdf = fitz.open()
        page = pdf.new_page()
        page.insert_text((72, 72), "Neurology PDF: stroke seizure cranial nerves.")
        assert_true("stroke" in bot.extract_text("pdf", pdf.tobytes()).lower(), "pdf extraction failed")

    assert_true(bot.extract_text("pdf", b"%PDF-not-real") == "", "corrupted pdf should return empty text")
    assert_true(bot.classify_document("application/zip", "deck.zip") == "zip", "zip classification failed")
    assert_true(bot.classify_document("application/octet-stream", "x.bin") == "unsupported", "unsupported classification failed")


async def test_callbacks() -> None:
    await bot.pp_insert_questions_batch(
        "ajdabiya",
        "anatomy",
        [
            {
                "question": "What is the heart?",
                "options": {"A": "Organ", "B": "Bone", "C": "Nerve", "D": "Skin"},
                "correct": "A",
                "explanation": "It is an organ.",
            }
        ],
    )
    source = (ROOT / "bot.py").read_text(encoding="utf-8")
    callbacks = sorted(set(re.findall(r"callback_data\s*=\s*['\"]([^'\"]+)['\"]", source)))
    callbacks.extend(
        [
            "pp:subject:ajdabiya:anatomy",
            "pp:mode:ajdabiya:anatomy:random",
            "pp:mode:ajdabiya:anatomy:ordered",
            "pp:quiz:ajdabiya:anatomy:random",
            "pp:progress:ajdabiya:anatomy",
            "pp:wrong:ajdabiya:anatomy",
            "adminq:browseuni:ajdabiya",
            "adminq:browsesubject:ajdabiya:anatomy",
            "adminq:item:ajdabiya:anatomy:0",
            "adminq:editans:ajdabiya:anatomy:0",
            "slide:answer:heart",
        ]
    )
    for data in callbacks:
        ctx = FakeContext()
        query, msg = await route_callback(data, ctx, user_id=111)
        merged = query.edits + msg.outputs
        assert_true(not any("حدث خطأ مؤقت" in item[1] for item in merged), f"generic error fallback for {data}: {merged}")


async def test_file_quiz_and_summary() -> None:
    bot.call_gemini = fake_call_gemini
    bot.should_use_queue = lambda: False
    bot.COOLDOWN_SECONDS = 0
    text = ("Cardiology lecture myocardial infarction troponin ECG aspirin STEMI chest pain. " * 5).encode()

    ctx = FakeContext()
    update, msg = make_update(FakeDocument("mi.txt", "text/plain", text), user_id=222)
    await bot.handle_file(update, ctx)
    assert_true("pending_file" in ctx.user_data, f"quiz upload did not create pending_file: {msg.outputs}")
    setup = ctx.user_data["pending_file"]["setup_id"]
    query, _ = await route_callback(f"level:{setup}:basic", ctx, user_id=222)
    assert_true(any("Basic" in item[1] or "كم" in item[1] for item in query.edits), f"level callback failed: {query.edits}")
    query2, _ = await route_callback(f"count:{setup}:5", ctx, user_id=222)
    assert_true(bool(ctx.user_data.get("session")), f"count callback did not start session: {query2.edits}")

    ctx2 = FakeContext()
    ctx2.user_data["pending_mode"] = "summary"
    ctx2.user_data["pending_summary_style"] = "highyield"
    update2, msg2 = make_update(FakeDocument("mi2.txt", "text/plain", text), user_id=223)
    await bot.handle_file(update2, ctx2)
    assert_true(any("ملخص" in item[1] or "احتشاء" in item[1] for item in msg2.outputs), f"summary flow failed: {msg2.outputs}")

    ctx3 = FakeContext()
    ctx3.user_data["pending_mode"] = "summary"
    ctx3.user_data["pending_summary_style"] = "highyield"
    update3, msg3 = make_update(FakeDocument("mi2.txt", "text/plain", text), user_id=224)
    await bot.handle_file(update3, ctx3)
    assert_true(any(item[0] == "reply" for item in msg3.outputs), f"cached summary flow failed: {msg3.outputs}")


async def test_admin_question_manager() -> None:
    q1 = {"question": "Q1", "options": {"A": "one", "B": "two", "C": "three", "D": "four"}, "correct": "A", "explanation": "e"}
    q2 = {"question": "Q2", "options": {"A": "alpha", "B": "beta", "C": "gamma", "D": "delta"}, "correct": "B", "explanation": "e"}
    await bot.pp_insert_questions_batch("ajdabiya", "anatomy", [q1, q2])
    questions = await bot.pp_load_questions("ajdabiya", "anatomy")
    fp1 = bot._pp_question_fingerprint(questions[0])
    fp2 = bot._pp_question_fingerprint(questions[1])

    con = sqlite3.connect(bot.DATABASE_PATH)
    con.execute(
        "INSERT OR REPLACE INTO past_question_attempts(user_id,uni,subject,fp,attempts,correct,wrong) VALUES(?,?,?,?,?,?,?)",
        (222, "ajdabiya", "anatomy", fp1, 1, 0, 1),
    )
    con.execute(
        "INSERT OR REPLACE INTO past_question_attempts(user_id,uni,subject,fp,attempts,correct,wrong) VALUES(?,?,?,?,?,?,?)",
        (222, "ajdabiya", "anatomy", fp2, 1, 1, 0),
    )
    con.execute(
        "INSERT OR REPLACE INTO past_progress(user_id,uni,subject,attempts,correct,wrong,wrong_json,updated_at) VALUES(?,?,?,?,?,?,?,?)",
        (222, "ajdabiya", "anatomy", 2, 1, 1, json.dumps(questions, ensure_ascii=False), "now"),
    )
    con.commit()
    con.close()

    await bot.pp_admin_update_question_answer_by_fp("ajdabiya", "anatomy", fp1, "B")
    after = await bot.pp_load_questions("ajdabiya", "anatomy")
    assert_true(bot._pp_question_fingerprint(after[0]) == fp1, "edit answer did not preserve fingerprint")
    assert_true(after[0]["correct"] == "B", "answer was not updated")

    await bot.pp_admin_delete_question_by_fp("ajdabiya", "anatomy", fp1)
    remaining = await bot.pp_load_questions("ajdabiya", "anatomy")
    con = sqlite3.connect(bot.DATABASE_PATH)
    con.row_factory = sqlite3.Row
    attempts = [r["fp"] for r in con.execute("SELECT fp FROM past_question_attempts ORDER BY fp").fetchall()]
    wrong_json = con.execute("SELECT wrong_json FROM past_progress WHERE user_id=222").fetchone()[0]
    con.close()
    assert_true(len(remaining) == 1 and bot._pp_question_fingerprint(remaining[0]) == fp2, "wrong question removed")
    assert_true(attempts == [fp2], f"attempt cleanup touched wrong rows: {attempts}")
    assert_true("Q1" not in wrong_json and "Q2" in wrong_json, "wrong_json cleanup touched wrong question")


async def test_slide_training() -> None:
    if Image is None:
        return
    mem_img = io.BytesIO()
    Image.new("RGB", (20, 20), (255, 255, 255)).save(mem_img, format="JPEG")
    deck = {
        "deck_id": "testdeck",
        "title": "Deck تجريبي",
        "slides": [
            {
                "slide_id": "s1",
                "image": "images/slide_001.jpg",
                "questions": [
                    {
                        "id": "q1",
                        "question": "What is this diagnosis?",
                        "answer": "myocardial infarction",
                        "accepted_keywords": ["MI", "myocardial infarction"],
                        "explanation": "classic",
                    }
                ],
            }
        ],
    }
    zip_mem = io.BytesIO()
    with zipfile.ZipFile(zip_mem, "w") as zf:
        zf.writestr("deck.json", json.dumps(deck, ensure_ascii=False))
        zf.writestr("images/slide_001.jpg", mem_img.getvalue())

    ctx = FakeContext()
    update, msg = make_update(user_id=111)
    await bot.handle_slide_deck_upload(update, ctx, zip_mem.getvalue(), "deck.zip")
    assert_true(any("تم رفع Deck" in item[1] for item in msg.outputs), f"slide deck upload failed: {msg.outputs}")

    loaded = bot._slide_load_deck()
    items = bot._slide_flatten(loaded or {})
    assert_true(len(items) == 1, "slide deck did not flatten to one item")
    assert_true(bot._slide_grade_answer("MI", items[0])[0] == "correct", "keyword grading failed")

    ctx2 = FakeContext()
    query, msg2 = await route_callback("slide:start", ctx2, user_id=222)
    assert_true(bool(ctx2.user_data.get("slide_session")), f"slide session not started: {query.edits} {msg2.outputs}")
    assert_true(any(item[0] in {"send_photo", "send_msg"} for item in msg2.outputs), f"slide question not sent: {msg2.outputs}")

    update3, msg3 = make_update(user_id=222)
    ctx2.bot = FakeBot(msg3.outputs)
    handled = await bot.handle_slide_training_text(update3, ctx2, "myocardial infarction")
    assert_true(bool(handled), "slide text answer not handled")
    assert_true(any("صح" in item[1] for item in msg3.outputs), f"slide grading reply failed: {msg3.outputs}")


def test_commands_and_removed_features() -> None:
    user_commands = {cmd.command for cmd in bot.USER_BOT_COMMANDS}
    admin_commands = {cmd.command for cmd in bot.ADMIN_BOT_COMMANDS}
    assert_true("osce" not in user_commands, "/osce still present in user command menu")
    assert_true("my_plan" not in user_commands and "payment_status" not in user_commands, "payment commands still present")
    assert_true(admin_commands == {"admin"}, f"admin command scope is not compact: {admin_commands}")
    source = (ROOT / "bot.py").read_text(encoding="utf-8").lower()
    for bad in ["payment_callback", "payment_admin_callback", "osce_command", "mode:osce", "payadmin:"]:
        assert_true(bad not in source, f"removed feature token still present: {bad}")


async def main() -> None:
    reset_db()
    test_database_init_and_cleanup()
    reset_db()
    test_text_extraction()
    reset_db()
    await test_callbacks()
    reset_db()
    await test_file_quiz_and_summary()
    reset_db()
    await test_admin_question_manager()
    reset_db()
    await test_slide_training()
    test_commands_and_removed_features()
    print("✅ MedMCQ offline stability smoke tests passed")


if __name__ == "__main__":
    asyncio.run(main())
