"""Alternative MedMCQ entry point.

The server deploy script can continue using bot.py. This file prepares the project for a future module-first layout.
"""

from bot import main


if __name__ == "__main__":
    main()
