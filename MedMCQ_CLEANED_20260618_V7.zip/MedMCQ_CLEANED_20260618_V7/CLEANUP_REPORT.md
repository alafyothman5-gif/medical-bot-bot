# Cleanup Report — 2026-06-18

## تنظيف بنيوي

- فكّ الحزمة الداخلية وتجهيز المشروع كمجلد مباشر.
- حذف `__pycache__` وملفات `.pyc`.
- نقل ملفات README القديمة إلى `docs/legacy/` بدل تكديسها في root.
- إنشاء `README.md`, `DEPLOY.md`, `SLIDE_DECK_FORMAT.md`.

## تنظيف أمني

- لا يوجد `.env` حقيقي داخل الحزمة.
- توسيع `.env.example` ليغطي متغيرات التشغيل بدون أسرار.
- تحسين `.gitignore` لمنع الأسرار، قواعد البيانات، اللوقات، والكاش.
- إخفاء تفاصيل أخطاء callback عن الطالب؛ التفاصيل تبقى في لوق السيرفر.
- إخفاء تفاصيل فشل رفع Deck عن المحادثة؛ التفاصيل تبقى في اللوق.

## تنظيف كود

- حذف التعريفين القديمين المكررين:
  - `stage_dump_cmd`
  - `admin_send_staging_zip`
- ترك التعريف النهائي الأحدث فقط لكل دالة.
- تعديل نصوص الدعم العامة حتى لا تطلب إثبات دفع في نسخة الدفع المعطل.
- تعديل رسالة نهاية تدريب السلايدات لأنها أصبحت عامة للطلاب وليست للأدمن فقط.
- إضافة حدود أمان لرفع ZIP السلايدات:
  - الحجم المضغوط.
  - عدد الملفات.
  - الحجم بعد فك الضغط.
  - أنواع الملفات المسموحة.

## أدوات مضافة

- `scripts/clean_project.sh`
- `scripts/check_project.py`

## نتيجة الفحص

- `python3 -m py_compile bot.py worker.py queue_jobs.py` ناجح.
- لا توجد دوال top-level مكررة في `bot.py` حسب فحص `scripts/check_project.py`.
- لا توجد ملفات `__pycache__` أو `.pyc` في النسخة النظيفة.

## V4 — Admin Question Manager + Leaderboard Removal

### Added
- Added admin-only `🧩 إدارة الأسئلة` section in the admin panel.
- Admin can browse past-paper questions by university and subject.
- Admin can open a specific question and manually:
  - delete it from the past-paper bank,
  - edit its correct answer,
  - add one new question directly using strict JSON validation.
- Direct question addition validates:
  - non-empty `question`,
  - required options `A/B/C/D`, optional `E`,
  - `correct` must be a valid existing option letter,
  - duplicate questions are rejected.
- Deleting a question also removes its per-question attempt rows and cleans it from saved wrong-question lists.
- Editing an answer preserves the question identity fingerprint through `source_fp` so old user progress is not reset.

### Removed/Disabled
- Removed the leaderboard button from the student interface.
- Removed visible leaderboard wording from the main menu.
- Removed the unused leaderboard database helper.
- Old `panel:leaderboard` callback now only returns a disabled-section notice for old Telegram messages.

### Safety
- All new question-management callbacks are restricted to `ADMIN_USER_IDS`.
- No Forensic/Ophthalmology deletion or hiding logic was added.
- No production database is included in this package.


## V5 — Start-only Admin Log

### Added
- Added persistent `/start` alert tracking in SQLite table `admin_start_alerts`.
- Added `ADMIN_START_ALERT_ENABLED`.
- Added `ADMIN_START_ALERT_COOLDOWN_SECONDS`, default `3600` seconds.
- `/admin_log_status` now shows that the log mode is `/start alerts only`.

### Changed
- Admin activity log no longer records routine button clicks.
- Admin activity log no longer records quiz answers or normal text messages.
- Admin activity log no longer records regular document/photo/poll events.
- `/start` alert message includes:
  - full name,
  - username,
  - Telegram user ID,
  - UTC timestamp,
  - cooldown note.

### Safety
- Log target still must be a channel/group through `ADMIN_LOG_CHAT_ID`, `ADMIN_LOG_CHANNEL_ID`, or `ADMIN_LOG_TARGET`.
- There is still no fallback to private admin chat.
- Cooldown is stored in SQLite, so it survives bot restarts.


## V6 — Past Papers compatibility + direct AI fallback

### Fixed
- Fixed `NameError: pp_subject_is_enabled is not defined` in the Past Papers university/subject menu.
- Restored Past Papers visibility without any subject hiding logic.
- `pp_load_questions()` now supports both database shapes:
  - grouped schema: `uni, subject, questions_json`,
  - legacy flat schema: `question, options, correct, source, year, subject, unit, source_fp`.
- Legacy flat rows without a university are shown for both Ajdabiya and Benghazi, so old data remains visible without manual database migration.
- Options stored as JSON/Python strings in SQLite are now parsed correctly.

### Queue / Worker behavior
- Added `should_use_queue()` health check.
- The bot now queues work only when Redis is reachable and `worker.py` is actually running.
- If Redis or worker is not available, uploads fall back to direct processing inside `bot.py` instead of staying stuck at “دخل الطلب في الطابور”.
- Admin preload also falls back to direct cache generation when no worker is available.

### Admin question manager compatibility
- Manual add/edit/delete now supports both grouped and legacy Past Papers tables.
- Stats now reads through the same compatibility loader.

### New environment controls
- `AUTO_QUEUE_FALLBACK=1`
- `QUEUE_REQUIRE_WORKER_PROCESS=1`

## V7 stability patch

- Fixed legacy/new `past_papers` compatibility without requiring manual DB migration.
- Fixed admin JSON upload so it works with both legacy flat and grouped past-paper schemas.
- Fixed legacy progress backfill so it does not crash on old flat `past_papers` tables.
- Registered admin log commands: `/admin_log_status`, `/admin_log_on`, `/admin_log_off`, `/admin_log_test`.
- Fixed admin semester ZIP preload loop and improved direct-cache fallback status.
- Preserved V6 behavior: no subject hiding/deleting and `/start` admin log only.
