MedMCQ - Past Papers Append-Only Progress Fix

What changed:
- Adding new past-paper questions no longer forces students who solved old questions to restart from zero.
- Added per-question past-paper progress table: past_question_attempts.
- Past-paper questions now keep a stable fingerprint before option shuffling.
- "حل بالترتيب / استكمال" now serves only unanswered questions.
- Added "🆕 حل الأسئلة الجديدة فقط" when the student has unseen newly added questions.
- Added "🔁 إعادة حل الكل" for students who intentionally want to restart the full bank.
- Legacy migration: if a student had already solved the old bank using the old aggregate progress, the bot backfills old questions as answered and leaves the newest uploaded batch unseen.
- Existing Admin Log channel, Admin Training admin-only, and persistent sessions remain.

Safe DB changes:
- Adds table only: past_question_attempts
- Does not delete past_papers
- Does not delete user progress
- Does not touch MedMCQ unrelated apps
