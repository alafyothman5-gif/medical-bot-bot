MedMCQ_ADMIN_TRAINING_PERSISTENT_SESSIONS_20260616

What changed:
1) Added student button: 🧠 تدريب الأدمن
   - This is separate from 📚 بنك السنوات السابقة.
   - It reads questions from table admin_training_questions.

2) Added admin panel button: 🧠 تدريب الأدمن
   - Admin can choose رفع JSON/ZIP لتدريب الأدمن.
   - Then send a .json file or .zip containing JSON files.
   - Accepted JSON formats: list directly, or {questions/items/data/mcqs: [...]}.
   - Questions are normalized using question/options/correct or question/choices/answer.

3) Added persistent sessions:
   - Active MCQ session is saved in table user_sessions.
   - If the bot restarts or code is updated, student can press /start then ▶️ استكمال آخر تدريب.
   - Old answer buttons can also restore the session if they match the saved quiz_id/current question.

4) Added commands:
   - /upload_training for admin upload mode
   - /clear_training to clear admin training table
   - /reset to clear current saved session

5) Existing admin log channel behavior remains unchanged.
