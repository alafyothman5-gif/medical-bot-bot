MedMCQ_ADMIN_TRAINING_ADMIN_ONLY_20260616

Changes:
- The 🧠 تدريب الأدمن button is visible only for admin users.
- Non-admin users do not see the admin training button in the main menu.
- If a non-admin taps an old cached admin-training callback, the bot returns them to the normal main menu.
- The admin panel still contains تدريب الأدمن upload/open controls for admins.
- Upload success text now states that the button appears for admins only.
- The public bot command list no longer exposes /upload_training, but the command handler remains available for admins who type it manually.
- No database deletion or data reset.
- Admin Log Channel behavior is unchanged.
- Persistent sessions behavior is unchanged.
