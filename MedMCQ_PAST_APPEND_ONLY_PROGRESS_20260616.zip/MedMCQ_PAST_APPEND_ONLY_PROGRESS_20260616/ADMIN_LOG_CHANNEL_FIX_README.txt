Admin Log channel restore

This build restores the original project behavior:
- Admin Log messages go to Telegram channel ID: -1003987051773 by default.
- No user-facing message is shown to students.
- /admin_log_here is optional, not required.
- The bot must be admin/member in that channel and allowed to post.

If you want to override target later, set ADMIN_LOG_CHAT_ID or ADMIN_ACTIVITY_LOG_TARGET_IDS in .env.
