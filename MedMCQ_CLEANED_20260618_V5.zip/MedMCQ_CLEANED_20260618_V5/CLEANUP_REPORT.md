# Cleanup Report — 2026-06-18

## تنظيف بنيوي

- فكّ الحزمة الداخلية وتجهيز المشروع كمجلد مباشر.
- حذف `__pycache__` وملفات `.pyc`.
- نقل ملفات README القديمة إلى `docs/legacy/` بدل تكديسها في root.
- إنشاء `README.md`, `DEPLOY.md`, `SLIDE_DECK_FORMAT.md`.

## تنظيف أمني

- لا يوجد `.env` حقيقي داخل الحزمة.
- توسيع `.env.example` ليغطي متغيرات التشغيل بدون أسرار.
- تحسين `.gitignore` لمنع الأسرار، قواعد البيانات، اللوقات، والكاش.
- إخفاء تفاصيل أخطاء callback عن الطالب؛ التفاصيل تبقى في لوق السيرفر.
- إخفاء تفاصيل فشل رفع Deck عن المحادثة؛ التفاصيل تبقى في اللوق.

## تنظيف كود

- حذف التعريفين القديمين المكررين:
  - `stage_dump_cmd`
  - `admin_send_staging_zip`
- ترك التعريف النهائي الأحدث فقط لكل دالة.
- تعديل نصوص الدعم العامة حتى لا تطلب إثبات دفع في نسخة الدفع المعطل.
- تعديل رسالة نهاية تدريب السلايدات لأنها أصبحت عامة للطلاب وليست للأدمن فقط.
- إضافة حدود أمان لرفع ZIP السلايدات:
  - الحجم المضغوط.
  - عدد الملفات.
  - الحجم بعد فك الضغط.
  - أنواع الملفات المسموحة.

## أدوات مضافة

- `scripts/clean_project.sh`
- `scripts/check_project.py`

## نتيجة الفحص

- `python3 -m py_compile bot.py worker.py queue_jobs.py` ناجح.
- لا توجد دوال top-level مكررة في `bot.py` حسب فحص `scripts/check_project.py`.
- لا توجد ملفات `__pycache__` أو `.pyc` في النسخة النظيفة.

## V4 — Admin Question Manager + Leaderboard Removal

### Added
- Added admin-only `🧩 إدارة الأسئلة` section in the admin panel.
- Admin can browse past-paper questions by university and subject.
- Admin can open a specific question and manually:
  - delete it from the past-paper bank,
  - edit its correct answer,
  - add one new question directly using strict JSON validation.
- Direct question addition validates:
  - non-empty `question`,
  - required options `A/B/C/D`, optional `E`,
  - `correct` must be a valid existing option letter,
  - duplicate questions are rejected.
- Deleting a question also removes its per-question attempt rows and cleans it from saved wrong-question lists.
- Editing an answer preserves the question identity fingerprint through `source_fp` so old user progress is not reset.

### Removed/Disabled
- Removed the leaderboard button from the student interface.
- Removed visible leaderboard wording from the main menu.
- Removed the unused leaderboard database helper.
- Old `panel:leaderboard` callback now only returns a disabled-section notice for old Telegram messages.

### Safety
- All new question-management callbacks are restricted to `ADMIN_USER_IDS`.
- No Forensic/Ophthalmology deletion or hiding logic was added.
- No production database is included in this package.


## V5 — Start-only Admin Log

### Added
- Added persistent `/start` alert tracking in SQLite table `admin_start_alerts`.
- Added `ADMIN_START_ALERT_ENABLED`.
- Added `ADMIN_START_ALERT_COOLDOWN_SECONDS`, default `3600` seconds.
- `/admin_log_status` now shows that the log mode is `/start alerts only`.

### Changed
- Admin activity log no longer records routine button clicks.
- Admin activity log no longer records quiz answers or normal text messages.
- Admin activity log no longer records regular document/photo/poll events.
- `/start` alert message includes:
  - full name,
  - username,
  - Telegram user ID,
  - UTC timestamp,
  - cooldown note.

### Safety
- Log target still must be a channel/group through `ADMIN_LOG_CHAT_ID`, `ADMIN_LOG_CHANNEL_ID`, or `ADMIN_LOG_TARGET`.
- There is still no fallback to private admin chat.
- Cooldown is stored in SQLite, so it survives bot restarts.
