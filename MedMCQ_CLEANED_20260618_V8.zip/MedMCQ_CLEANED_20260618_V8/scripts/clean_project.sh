#!/usr/bin/env bash
set -euo pipefail
find . -type d -name "__pycache__" -prune -exec rm -rf {} +
find . -type f \( -name "*.pyc" -o -name "*.pyo" \) -delete
find . -type f \( -name "*.log" -o -name "nohup.out" \) -delete
printf 'Cleaned generated Python cache and log files.\n'
