#!/usr/bin/env python3
"""Lightweight static checks before deployment."""
from __future__ import annotations

import ast
import pathlib
import py_compile
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
PY_FILES = [ROOT / "bot.py", ROOT / "worker.py", ROOT / "queue_jobs.py"]


def fail(msg: str) -> None:
    print(f"❌ {msg}")
    sys.exit(1)


def _remove_pycache() -> None:
    for cache_dir in ROOT.rglob("__pycache__"):
        shutil.rmtree(cache_dir, ignore_errors=True)


def check_compile() -> None:
    for path in PY_FILES:
        py_compile.compile(str(path), doraise=True)
    _remove_pycache()
    print("✅ Python syntax compile passed")


def check_no_runtime_artifacts() -> None:
    forbidden = []
    for p in ROOT.rglob("*"):
        rel = p.relative_to(ROOT).as_posix()
        if "__pycache__" in rel or p.suffix in {".pyc", ".pyo"}:
            forbidden.append(rel)
    if forbidden:
        fail("Runtime artifacts found: " + ", ".join(forbidden[:10]))
    print("✅ No __pycache__ / pyc artifacts")


def check_no_real_env() -> None:
    if (ROOT / ".env").exists():
        fail("Real .env file exists in project root. Remove it before publishing.")
    print("✅ No real .env in project root")


def check_duplicate_top_level_functions() -> None:
    text = (ROOT / "bot.py").read_text(encoding="utf-8")
    mod = ast.parse(text)
    seen: dict[str, list[int]] = {}
    for node in mod.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            seen.setdefault(node.name, []).append(node.lineno)
    dup = {name: lines for name, lines in seen.items() if len(lines) > 1}
    if dup:
        fail("Duplicate top-level functions: " + repr(dup))
    print("✅ No duplicate top-level functions")


def main() -> None:
    check_compile()
    check_no_runtime_artifacts()
    check_no_real_env()
    check_duplicate_top_level_functions()
    print("✅ Project check completed")


if __name__ == "__main__":
    main()
