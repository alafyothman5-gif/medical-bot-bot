# Deploy MedMCQ on server

## 1. تجهيز الملفات

من داخل مجلد المشروع:

```bash
./scripts/clean_project.sh
python3 scripts/check_project.py
```

## 2. تثبيت الاعتمادات

```bash
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
mkdir -p data
```

## 3. تجهيز `.env`

```bash
cp .env.example .env
nano .env
```

املأ على الأقل:

```env
TELEGRAM_BOT_TOKEN=...
ADMIN_USER_IDS=123456789
DATABASE_PATH=data/bot_cache.sqlite3
```

ثم أضف مفاتيح AI التي تريد استخدامها.


## 3.1 قناة Admin Log

لإرسال تنبيه عند دخول الطالب للبوت عبر `/start` فقط، اجعل البوت Admin داخل قناة/جروب اللوق، ثم ضع:

```env
ADMIN_LOG_CHAT_ID=-100xxxxxxxxxx
ADMIN_ACTIVITY_LOG_ENABLED=1
ADMIN_START_ALERT_ENABLED=1
ADMIN_START_ALERT_COOLDOWN_SECONDS=3600
```

السلوك:
- يرسل تنبيه عند `/start` فقط.
- لا يسجل الأزرار أو حل الأسئلة أو النصوص العادية.
- نفس المستخدم لا يظهر مرة ثانية إلا بعد ساعة افتراضيًا.


## 4. تشغيل البوت

```bash
python3 -m py_compile bot.py worker.py queue_jobs.py
nohup python3 bot.py > nohup.out 2>&1 &
```

لو `USE_QUEUE=1`:

```bash
nohup python3 worker.py > worker.log 2>&1 &
```

## 5. فحص اللوق

```bash
tail -100 nohup.out
tail -100 worker.log
```

## 6. إعادة تشغيل آمنة

```bash
pkill -f "bot.py" || true
pkill -f "worker.py" || true
nohup python3 bot.py > nohup.out 2>&1 &
nohup python3 worker.py > worker.log 2>&1 &
```

## ملاحظات مهمة

- هذه الحزمة لا تشغل `sms_webhook.py` ولا `payment_watchdog.py` لأن الدفع معطل افتراضيًا.
- عند إعادة تفعيل الدفع لاحقًا، أضف ملفات الدفع من نسخة production بعد مراجعة الأسرار.
- قاعدة SQLite يجب أن تبقى على السيرفر ولا تُرفع إلى GitHub.
