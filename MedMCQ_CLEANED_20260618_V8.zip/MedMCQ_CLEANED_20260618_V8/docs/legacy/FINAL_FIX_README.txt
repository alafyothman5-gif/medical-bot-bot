MedMCQ FINAL - Slides Public + Channel-only Admin Log

Built from the last V2 safe version.
Preserved:
- Past paper resume/new-only buttons.
- Existing question bank and student progress.
- Admin training and upload flows.
- Slide deck support with multiple images per question.

Final fixes:
1) Slide Training is now public for students.
   - Main menu button: 🖼️ تدريب السلايدات
   - /slides works for everyone.
   - Students can start training, answer, view stats, retry wrong.
   - Only admins can upload/update the deck.

2) Admin Log no longer falls back to private admin chat.
   - Logs go only to ADMIN_LOG_CHAT_ID / ADMIN_LOG_CHANNEL_ID / ADMIN_LOG_TARGET.
   - If no channel/group target is configured, logs are silent instead of being sent to the bot/private chat.
   - Use /admin_log_status and /admin_log_test as admin.

3) No destructive DB action.
   - No deletion of past papers.
   - No deletion of progress.
   - No replacement of user data.
