MedMCQ Slide Training — Admin Only v1

What this version adds:
- New admin-only button: 🖼️ تدريب السلايدات (أدمن)
- Anki-like slide training:
  1) shows one slide image
  2) shows one question under it
  3) admin writes the answer
  4) bot accepts spelling mistakes / partial clear answers using accepted_keywords + fuzzy matching
  5) bot shows the correct answer
  6) next button moves to the next question, even if it is from the same slide
- Each slide can have multiple questions.
- First version is blocked for non-admin users.
- Saves progress in slide_training_progress.
- Supports uploading a ZIP deck from the admin button:
  deck.json + images/slide_001.jpg ...

Default included test deck:
- Ajdabiya OSCE Slides — Admin Test v1
- 6 slides
- 20 questions

Deck JSON shape:
{
  "deck_id": "ajdabiya_osce_v1",
  "title": "Ajdabiya OSCE Slides",
  "slides": [
    {
      "slide_id": "OSCE-SLIDE-001",
      "slide_number": 1,
      "image": "images/slide_001.jpg",
      "questions": [
        {
          "id": "S001-Q1",
          "question": "What is the diagnosis?",
          "answer": "Erb's palsy",
          "accepted_keywords": ["erb", "erb palsy", "brachial plexus injury", "شلل ارب"]
        }
      ]
    }
  ]
}
