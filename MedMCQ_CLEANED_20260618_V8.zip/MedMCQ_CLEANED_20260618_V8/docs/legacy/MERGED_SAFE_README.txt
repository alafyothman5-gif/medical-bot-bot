MedMCQ merged safe build

Includes both:
- Slide training admin-only multi-image support.
- Past paper append-only progress buttons:
  * 🆕 حل الأسئلة الجديدة فقط
  * 📚 حل بالترتيب / استكمال
  * 🔁 إعادة حل الكل
- Adds only safe table: past_question_attempts.
- Does not delete past_papers, past_progress, or existing student data.
