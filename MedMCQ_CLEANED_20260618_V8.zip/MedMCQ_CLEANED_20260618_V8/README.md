# MedMCQ Bot — Clean Working Package

نسخة تشغيل نظيفة من بوت MedMCQ، جاهزة للتعديل والنشر بدون ملفات أسرار أو كاش تشغيل.

## ماذا يحتوي المشروع؟

- `bot.py` — البوت الرئيسي.
- `worker.py` — عامل الخلفية لمعالجة المهام الثقيلة عند تفعيل Redis queue.
- `queue_jobs.py` — طبقة Redis queue.
- `data/slide_training/active/` — Deck تدريبي تجريبي للسلايدات.
- `.env.example` — قالب إعدادات آمن بدون أسرار.
- `scripts/check_project.py` — فحص سريع قبل النشر.
- `scripts/clean_project.sh` — حذف كاش بايثون واللوق المحلي.

## الحالة الحالية للميزات

| الميزة | الحالة |
|---|---|
| رفع محاضرات وتحويلها لملخص/أسئلة | موجود |
| Past Papers | مفتوح للطلاب في هذه النسخة |
| Slide Training | متاح للطلاب، والرفع للأدمن فقط |
| Admin staging | موجود |
| Admin activity log | تنبيهات /start فقط إلى قناة/جروب، مع منع التكرار لمدة ساعة لكل مستخدم |
| الدفع والاشتراك | معطل افتراضيًا |
| SMS webhook / watchdog | غير مرفق في هذه الحزمة النظيفة |

## تشغيل محلي سريع

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# عدّل TELEGRAM_BOT_TOKEN ومفاتيح الذكاء الاصطناعي داخل .env
python3 scripts/check_project.py
python3 bot.py
```

عند تفعيل `USE_QUEUE=1` شغّل العامل في terminal آخر:

```bash
python3 worker.py
```

## قواعد أمان مهمة

- لا ترفع `.env` إلى GitHub.
- لا ترفع قاعدة بيانات التشغيل `data/*.sqlite3`.
- لا ترفع ملفات log أو `__pycache__`.
- لا تضع توكنات أو مفاتيح API داخل الكود.
- قبل كل رفع إلى GitHub شغّل:

```bash
./scripts/clean_project.sh
python3 scripts/check_project.py
```

## الوثائق

- `DEPLOY.md` — خطوات النشر على السيرفر.
- `SLIDE_DECK_FORMAT.md` — صيغة Deck السلايدات.
- `CLEANUP_REPORT.md` — ما تم تنظيفه في هذه النسخة.
- `docs/legacy/` — ملفات README القديمة محفوظة للرجوع فقط.


## Admin Question Manager

The admin panel includes `🧩 إدارة الأسئلة` for manual maintenance of past-paper questions.

Available admin-only actions:

- Browse questions by university and subject.
- Delete one unwanted question after confirmation.
- Edit the correct answer of an existing question.
- Add one direct question using strict JSON validation.

Direct-add JSON format:

```json
{
  "question": "Question text",
  "options": {
    "A": "Option A",
    "B": "Option B",
    "C": "Option C",
    "D": "Option D",
    "E": "Optional Option E"
  },
  "correct": "A",
  "explanation": "Optional explanation"
}
```

The leaderboard section has been removed from the student interface. Student progress remains available through `📊 تقدمي`.


## Admin Start Alerts

قناة الأدمن لوق أصبحت للتنبيه عند `/start` فقط.

السلوك الحالي:

- عند دخول أي طالب للبوت عبر `/start` يتم إرسال تنبيه إلى قناة/جروب الأدمن.
- لا يتم تسجيل ضغطات الأزرار.
- لا يتم تسجيل حل الأسئلة.
- لا يتم تسجيل النصوص أو الملفات أو الصور كأحداث نشاط عادية.
- نفس المستخدم لا يظهر مرة أخرى إلا بعد مرور `ADMIN_START_ALERT_COOLDOWN_SECONDS`، والافتراضي ساعة واحدة.

الإعدادات المطلوبة في `.env`:

```env
ADMIN_LOG_CHAT_ID=-100xxxxxxxxxx
ADMIN_ACTIVITY_LOG_ENABLED=1
ADMIN_START_ALERT_ENABLED=1
ADMIN_START_ALERT_COOLDOWN_SECONDS=3600
```

يجب أن يكون البوت Admin داخل القناة/الجروب المستهدف.


## V6 operational note

This build is safe on servers that run only `bot.py` without a separate `worker.py` process.
When `USE_QUEUE=1`, the bot checks Redis and the worker process before creating jobs. If the worker is not running, the bot processes summaries and question generation directly so uploaded files do not remain stuck in the queue.

Past Papers are compatible with both the new grouped database schema and the older flat `past_papers` table. No manual schema conversion is required for students to see the bank.

## V7 stability patch

- Fixed legacy/new `past_papers` compatibility without requiring manual DB migration.
- Fixed admin JSON upload so it works with both legacy flat and grouped past-paper schemas.
- Fixed legacy progress backfill so it does not crash on old flat `past_papers` tables.
- Registered admin log commands: `/admin_log_status`, `/admin_log_on`, `/admin_log_off`, `/admin_log_test`.
- Fixed admin semester ZIP preload loop and improved direct-cache fallback status.
- Preserved V6 behavior: no subject hiding/deleting and `/start` admin log only.

## V8 command menu cleanup

V8 keeps the Telegram command menu compact:

Student-visible commands:
- `/start` — الرئيسية
- `/help` — المساعدة
- `/stats` — تقدمي
- `/review` — مراجعة أخطائي
- `/osce` — تدريب الأوسكي
- `/slides` — تدريب السلايدات
- `/support` — الدعم
- `/stop` — إنهاء الوضع الحالي

Admin users additionally see:
- `/admin` — opens the admin panel

Detailed admin tools are available from the inline admin panel instead of cluttering the Telegram menu.
